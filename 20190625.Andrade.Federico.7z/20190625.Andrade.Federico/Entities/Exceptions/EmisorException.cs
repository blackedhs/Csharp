﻿using System;

namespace Entities.Exceptions
{
    public class EmisorException :Exception
    {
        public EmisorException(string e):base (e)
        {
        }
    }
}
